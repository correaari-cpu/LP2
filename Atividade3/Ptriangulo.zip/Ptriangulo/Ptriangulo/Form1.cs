﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {   
        double Lado1, Lado2, Lado3;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtboxLado1_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }
            if (!Double.TryParse(txtboxLado1.Text, out Lado1)||(Lado1<=0))
            {
                MessageBox.Show("Número Inválido");
                txtboxLado1.Focus();
            }
        }

        private void txtboxLado2_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }
            if (!Double.TryParse(txtboxLado2.Text, out Lado2) || (Lado2 <= 0))
            {
                MessageBox.Show("Número Inválido");
                txtboxLado2.Focus();
            }
        }

        private void txtboxLado3_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }
            if (!Double.TryParse(txtboxLado3.Text, out Lado3) || (Lado3 <= 0))
            {
                MessageBox.Show("Número Inválido");
                txtboxLado3.Focus();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Math.Abs(Lado2 - Lado3) < Lado1 && (Lado2 + Lado3) > Lado1 && Math.Abs(Lado1 - Lado3) < Lado2 && (Lado1 + Lado3) > Lado2 && 
                Math.Abs(Lado1 - Lado2) < Lado3 && (Lado1 + Lado2) > Lado3)
            {
                if (Lado1 == Lado2 && Lado2 == Lado3)
                {
                    txtboxTipo.Text = "Triângulo Equilátero";
                }
                else
                    if ((Lado1 == Lado2 && Lado3 != Lado1) || (Lado2 == Lado3 && Lado1 != Lado2) || (Lado3 == Lado1 && Lado2 != Lado3))
                    txtboxTipo.Text = "Triângulo Isósceles";
                else
                    txtboxTipo.Text = "Triângulo Escaleno";
            }
            else
            {
                MessageBox.Show("As dimensões não caracterizam um Triângulo. Digite novamente");
                txtboxLado1.Focus();
            }
        }
        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtboxLado1.Text = "";
            txtboxLado2.Text = "";
            txtboxLado3.Text = "";
            txtboxTipo.Text = "";
            Lado1 = 0;
            Lado2 = 0;
            Lado3 = 0;
            txtboxLado1.Focus();

        }
    }
}
