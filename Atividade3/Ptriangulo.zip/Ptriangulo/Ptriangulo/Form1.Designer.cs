﻿namespace Ptriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lblLado1 = new System.Windows.Forms.Label();
            this.txtboxLado1 = new System.Windows.Forms.TextBox();
            this.lblLado2 = new System.Windows.Forms.Label();
            this.txtboxLado2 = new System.Windows.Forms.TextBox();
            this.lblLado3 = new System.Windows.Forms.Label();
            this.txtboxLado3 = new System.Windows.Forms.TextBox();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnTipo = new System.Windows.Forms.Button();
            this.lblTipo = new System.Windows.Forms.Label();
            this.txtboxTipo = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblLado1
            // 
            this.lblLado1.AutoSize = true;
            this.lblLado1.Location = new System.Drawing.Point(42, 36);
            this.lblLado1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLado1.Name = "lblLado1";
            this.lblLado1.Size = new System.Drawing.Size(63, 24);
            this.lblLado1.TabIndex = 0;
            this.lblLado1.Text = "Lado 1";
            // 
            // txtboxLado1
            // 
            this.txtboxLado1.Location = new System.Drawing.Point(113, 30);
            this.txtboxLado1.Margin = new System.Windows.Forms.Padding(4);
            this.txtboxLado1.Name = "txtboxLado1";
            this.txtboxLado1.Size = new System.Drawing.Size(124, 30);
            this.txtboxLado1.TabIndex = 1;
            this.txtboxLado1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtboxLado1.Validated += new System.EventHandler(this.txtboxLado1_Validated);
            // 
            // lblLado2
            // 
            this.lblLado2.AutoSize = true;
            this.lblLado2.Location = new System.Drawing.Point(42, 93);
            this.lblLado2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLado2.Name = "lblLado2";
            this.lblLado2.Size = new System.Drawing.Size(63, 24);
            this.lblLado2.TabIndex = 2;
            this.lblLado2.Text = "Lado 2";
            // 
            // txtboxLado2
            // 
            this.txtboxLado2.Location = new System.Drawing.Point(113, 87);
            this.txtboxLado2.Margin = new System.Windows.Forms.Padding(4);
            this.txtboxLado2.Name = "txtboxLado2";
            this.txtboxLado2.Size = new System.Drawing.Size(124, 30);
            this.txtboxLado2.TabIndex = 3;
            this.txtboxLado2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtboxLado2.Validated += new System.EventHandler(this.txtboxLado2_Validated);
            // 
            // lblLado3
            // 
            this.lblLado3.AutoSize = true;
            this.lblLado3.Location = new System.Drawing.Point(42, 160);
            this.lblLado3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLado3.Name = "lblLado3";
            this.lblLado3.Size = new System.Drawing.Size(63, 24);
            this.lblLado3.TabIndex = 4;
            this.lblLado3.Text = "Lado 3";
            // 
            // txtboxLado3
            // 
            this.txtboxLado3.Location = new System.Drawing.Point(113, 154);
            this.txtboxLado3.Margin = new System.Windows.Forms.Padding(4);
            this.txtboxLado3.Name = "txtboxLado3";
            this.txtboxLado3.Size = new System.Drawing.Size(124, 30);
            this.txtboxLado3.TabIndex = 5;
            this.txtboxLado3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtboxLado3.Validated += new System.EventHandler(this.txtboxLado3_Validated);
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.Color.LightCoral;
            this.btnSair.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.Location = new System.Drawing.Point(281, 13);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(102, 47);
            this.btnSair.TabIndex = 6;
            this.btnSair.Text = "SAIR";
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.BackColor = System.Drawing.Color.Khaki;
            this.btnLimpar.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.Location = new System.Drawing.Point(281, 80);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(102, 44);
            this.btnLimpar.TabIndex = 7;
            this.btnLimpar.Text = "LIMPAR";
            this.btnLimpar.UseVisualStyleBackColor = false;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnTipo
            // 
            this.btnTipo.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.btnTipo.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTipo.Location = new System.Drawing.Point(281, 142);
            this.btnTipo.Name = "btnTipo";
            this.btnTipo.Size = new System.Drawing.Size(102, 56);
            this.btnTipo.TabIndex = 8;
            this.btnTipo.Text = "TIPO TRIÂNGULO";
            this.btnTipo.UseVisualStyleBackColor = false;
            this.btnTipo.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblTipo
            // 
            this.lblTipo.AutoSize = true;
            this.lblTipo.Location = new System.Drawing.Point(42, 242);
            this.lblTipo.Name = "lblTipo";
            this.lblTipo.Size = new System.Drawing.Size(191, 24);
            this.lblTipo.TabIndex = 9;
            this.lblTipo.Text = "Seu triângulo é do tipo:";
            // 
            // txtboxTipo
            // 
            this.txtboxTipo.Enabled = false;
            this.txtboxTipo.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxTipo.ForeColor = System.Drawing.Color.Black;
            this.txtboxTipo.Location = new System.Drawing.Point(46, 280);
            this.txtboxTipo.Name = "txtboxTipo";
            this.txtboxTipo.Size = new System.Drawing.Size(321, 30);
            this.txtboxTipo.TabIndex = 10;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(479, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(340, 297);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(852, 351);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txtboxTipo);
            this.Controls.Add(this.lblTipo);
            this.Controls.Add(this.btnTipo);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.txtboxLado3);
            this.Controls.Add(this.lblLado3);
            this.Controls.Add(this.txtboxLado2);
            this.Controls.Add(this.lblLado2);
            this.Controls.Add(this.txtboxLado1);
            this.Controls.Add(this.lblLado1);
            this.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblLado1;
        private System.Windows.Forms.TextBox txtboxLado1;
        private System.Windows.Forms.Label lblLado2;
        private System.Windows.Forms.TextBox txtboxLado2;
        private System.Windows.Forms.Label lblLado3;
        private System.Windows.Forms.TextBox txtboxLado3;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnTipo;
        private System.Windows.Forms.Label lblTipo;
        private System.Windows.Forms.TextBox txtboxTipo;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

