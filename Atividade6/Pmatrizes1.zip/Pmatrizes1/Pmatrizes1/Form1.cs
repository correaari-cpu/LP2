﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] Vetor = new int[20];
            string aux = "";
            for (int i = 0; i < Vetor.Length; i++)
            {
                aux = Interaction.InputBox($"Digite Número {i + 1}", "Entrada de Dados");

                if (!int.TryParse(aux, out Vetor[i]))
                {
                    MessageBox.Show("Valor Inválido");
                    i--;
                }
            }
            Array.Reverse(Vetor);
            aux = "";
            foreach (int x in Vetor)
                aux += x + "\n";
            MessageBox.Show(aux);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList();
            alunos.Add("Ana");
            alunos.Add("André");
            alunos.Add("Beatriz");
            alunos.Add("Camila");
            alunos.Add("João");
            alunos.Add("Joana");
            alunos.Add("Otávio");
            alunos.Add("Marcelo");
            alunos.Add("Pedro");
            alunos.Add("Thais");
            alunos.Remove("Otávio");

            string aux = "";
            foreach(string x  in alunos)
                aux += x + "\n";
            MessageBox.Show(aux);
            
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            double[] media = new double[3];

            string resultado = "";

            for (int i = 0; i < notas.GetLength(0); i++)
            {
                double soma = 0;

                for (int j = 0; j < notas.GetLength(1); j++)
                {
                    string entrada = Interaction.InputBox(
                        $"Digite a Nota {j + 1} do aluno {i + 1} (0 a 10):");

                    notas[i, j] = Convert.ToDouble(entrada);

                    if (notas[i, j] < 0 || notas[i, j] > 10)
                    {
                        MessageBox.Show("Nota inválida!");
                        j--;
                    }
                    else
                    {
                        soma += notas[i, j];
                    }
                }

                media[i] = soma / 3;
            }
            resultado = "Aluno\tNota1\tNota2\tNota3\tMédia\n\n";

            for (int i = 0; i < notas.GetLength(0); i++)
            {
                resultado += $"{i + 1}\t" +
                             $"{notas[i, 0]}\t" +
                             $"{notas[i, 1]}\t" +
                             $"{notas[i, 2]}\t" +
                             $"{media[i]:F2}\n";
            }
            MessageBox.Show(resultado);
        }
        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio4>().Count() > 0)
            {
                Application.OpenForms["FrmExercicio4"].BringToFront();
            }
            else
            {
                FrmExercicio4 frmExercicio4 = new FrmExercicio4();
                frmExercicio4.Show();
            }

        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio5>().Count() > 0)
            {
                Application.OpenForms["FrmExercicio5"].BringToFront();
            }
            else
            {
                FrmExercicio5 frmExercicio5 = new FrmExercicio5();
                frmExercicio5.Show();
            }
        }
    }
}
