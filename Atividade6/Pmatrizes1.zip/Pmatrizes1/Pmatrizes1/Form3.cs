﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatrizes1
{
    public partial class FrmExercicio5 : Form
    {
        public FrmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string ra = Interaction.InputBox("Digite o número do RA:");
            
            int ultimoDigito = Convert.ToInt32(ra.Substring(ra.Length - 1, 1));

            int n;

            if (ultimoDigito == 0)
            {
                n = 2;
            }
            else
            {
                n = ultimoDigito + 1;
            }

            string[,] mRespostas = new string[n, 10];

            string[] vGabarito = { "A", "B", "C", "D", "E", "A", "B", "C", "D", "E" };

            lstBox.Items.Clear();

            for (int i = 0; i < mRespostas.GetLength(0); i++)
            {
                int acertos = 0;

                for (int j = 0; j < mRespostas.GetLength(1); j++)
                {
                    string resposta;

                    do
                    {
                        resposta = Interaction.InputBox(
                            $"Aluno {i + 1} - Questão {j + 1}\nDigite A, B, C, D ou E:"
                        ).ToUpper();

                    }
                    while (resposta != "A" &&
                           resposta != "B" &&
                           resposta != "C" &&
                           resposta != "D" &&
                           resposta != "E");

                    mRespostas[i, j] = resposta;

                    if (mRespostas[i, j] == vGabarito[j])
                    {
                        acertos++;
                    }
                }
                lstBox.Items.Add($"Aluno {i + 1} acertou {acertos} questões");
            }
        }
    }
}
