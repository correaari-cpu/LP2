﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatrizes1
{
    public partial class FrmExercicio4 : Form
    {
        public FrmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecuta_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            for (int i = 0; i < nomes.Length; i++)
            {
                string entrada = Interaction.InputBox($"Nome {i + 1}:");
                nomes[i] = entrada;
                int qtde = nomes[i].Replace(" ", "").Length;
                lstBox.Items.Add($"O nome {nomes[i]} tem {qtde} caracteres");

            }
        }
    }
}
