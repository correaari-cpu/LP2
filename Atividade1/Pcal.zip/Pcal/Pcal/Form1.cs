﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcal
{
    public partial class Form1 : Form
    {
        double Num1, Num2, Resultado; /*criação de variáveis globais*/
        public Form1()
        {
            InitializeComponent();
        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl==btnSair)
            {
                return;
            }
            if (!Double.TryParse(txtNum1.Text, out Num1))
            {
                MessageBox.Show("Número Inválido");
                txtNum1.Focus();
            }
        }
    }
}
