﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{   
    public partial class Form1 : Form
    {   
        double Peso, Altura, IMC; /*Variaveis globais criadas*/
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtPeso_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnFechar) /* se entrar num looping, ao acionar o botão fechar ele sai */
            {
                return;
            }
            if (!Double.TryParse(txtPeso.Text, out Peso)||(Peso<=0)) /*Testa vazio ou menor que zero. Se ok, converte text em número */
            {
                MessageBox.Show("Número Inválido");
                txtPeso.Focus();
            }
        }

        private void mkdTxtAltura_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnFechar) /* se entrar num looping, ao acionar o botão fechar ele sai. Se ok, converte text em número */
            {
                return;
            }
            if (!Double.TryParse(mkdTxtAltura.Text, out Altura) || (Altura <= 0)) /*Testa vazio ou menor que zero */
            {
                MessageBox.Show("Número Inválido");
                mkdTxtAltura.Focus();
            }
        }

        private void txtImc_TextChanged(object sender, EventArgs e)
        {
           

        }

        private void button2_Click(object sender, EventArgs e)
        {
            IMC = Math.Round((Peso / (Altura*Altura)),2);
           // IMC = IMC,2);
            txtImc.Text = IMC.ToString();
            if (IMC <= 18.5)
                txtResultado.Text = "Magreza - Obesidade grau 0";
            else if (IMC <= 24.9)
                txtResultado.Text = "Normal - Obesidade grau 0";
            else if (IMC <= 29.9)
                txtResultado.Text = "Sobrepeso - Obesidade grau I";
            else if (IMC <= 39.9)
                txtResultado.Text = "Obesidade - grau II";
            else
                txtResultado.Text = "Obesidade grave - grau III";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPeso.Clear();
            mkdTxtAltura.Clear();
            txtImc.Clear();
            txtResultado.Clear();
            Peso = 0;
            Altura = 0;
            IMC = 0;
        }
    }
}
